# plg_content_cgnewflag_j4
<p>CG New Flag Content Plugin - Display new flag for new articles</p>
